# Eleganium

![Eleganium screenshot](./preview/screen.png)