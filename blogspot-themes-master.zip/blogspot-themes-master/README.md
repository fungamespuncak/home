# Blogspot (Blogger) Templates [![Gitter](https://img.shields.io/gitter/room/nwjs/nw.js.svg)](https://gitter.im/web-xaser/blogger-templates) [![License](https://img.shields.io/npm/l/express.svg)](http://web-xaser.mit-license.org/) 
Templates for Google's blog platform [Blogger.com](https://blogger.com/). 

How to install a template?

1. Download the template
2. Go to your blog template section (Dashboard → Template → "Backup / Restore" button)
3. Backup your previous template ("Download full template" button)
4. Choose the template.xml file and upload it
5. You are awesome :clap:

[![ko-fi](https://www.ko-fi.com/img/donate_sm.png)](https://ko-fi.com/S6S26XLF)
